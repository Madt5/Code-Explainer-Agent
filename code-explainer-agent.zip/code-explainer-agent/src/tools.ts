import { promises as fs } from "node:fs";
import path from "node:path";
import type Anthropic from "@anthropic-ai/sdk";

const IGNORED = new Set(["node_modules", ".git", "dist", ".next", "__pycache__"]);
const MAX_FILE_CHARS = 20_000;

/** Resolve a relative path and make sure it stays inside the project root. */
export function resolveInside(root: string, rel: string): string {
  const full = path.resolve(root, rel);
  if (full !== root && !full.startsWith(root + path.sep)) {
    throw new Error(`Access denied: "${rel}" is outside the project folder.`);
  }
  return full;
}

async function listFiles(root: string, dir = "."): Promise<string> {
  const entries = await fs.readdir(resolveInside(root, dir), { withFileTypes: true });
  const lines = entries
    .filter((e) => !IGNORED.has(e.name))
    .map((e) => (e.isDirectory() ? `${e.name}/` : e.name))
    .sort();
  return lines.length ? lines.join("\n") : "(empty directory)";
}

async function readFile(root: string, file: string): Promise<string> {
  const content = await fs.readFile(resolveInside(root, file), "utf8");
  return content.length > MAX_FILE_CHARS
    ? content.slice(0, MAX_FILE_CHARS) + "\n...[truncated]"
    : content;
}

/** Tool schemas that are sent to the model. */
export const toolDefinitions: Anthropic.Tool[] = [
  {
    name: "list_files",
    description:
      "List files and folders in a directory of the project. Paths are relative to the project root.",
    input_schema: {
      type: "object",
      properties: {
        directory: { type: "string", description: 'Relative directory path, e.g. "src". Use "." for the root.' },
      },
      required: ["directory"],
    },
  },
  {
    name: "read_file",
    description: "Read the text content of a file in the project. Path is relative to the project root.",
    input_schema: {
      type: "object",
      properties: {
        path: { type: "string", description: 'Relative file path, e.g. "package.json".' },
      },
      required: ["path"],
    },
  },
];

/** Execute a tool call requested by the model. Errors are returned as text so the model can recover. */
export async function runTool(root: string, name: string, input: unknown): Promise<string> {
  try {
    const args = input as Record<string, string>;
    switch (name) {
      case "list_files":
        return await listFiles(root, args.directory);
      case "read_file":
        return await readFile(root, args.path);
      default:
        return `Unknown tool: ${name}`;
    }
  } catch (err) {
    return `Error: ${err instanceof Error ? err.message : String(err)}`;
  }
}
