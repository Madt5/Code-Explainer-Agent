import "dotenv/config";
import path from "node:path";
import Anthropic from "@anthropic-ai/sdk";
import { toolDefinitions, runTool } from "./tools.js";

const MODEL = process.env.MODEL ?? "claude-sonnet-5-5";
const MAX_STEPS = 15;

const SYSTEM_PROMPT = `You are a code explainer agent. You are given access to a project folder through two tools: list_files and read_file.
Explore the project yourself: start with the root folder and the README or package manifest, then read only the files you need.
Answer the user's question clearly and concisely. Mention the file names you based your answer on.
If something is not in the files, say so instead of guessing.`;

async function main() {
  const [, , targetDir, ...rest] = process.argv;
  const question = rest.join(" ").trim();

  if (!targetDir || !question) {
    console.error('Usage: npm start -- <project-folder> "<your question>"');
    process.exit(1);
  }
  if (!process.env.ANTHROPIC_API_KEY) {
    console.error("Missing ANTHROPIC_API_KEY. Copy .env.example to .env and add your key.");
    process.exit(1);
  }

  const root = path.resolve(targetDir);
  const client = new Anthropic();
  const messages: Anthropic.MessageParam[] = [{ role: "user", content: question }];

  for (let step = 1; step <= MAX_STEPS; step++) {
    const response = await client.messages.create({
      model: MODEL,
      max_tokens: 1500,
      system: SYSTEM_PROMPT,
      tools: toolDefinitions,
      messages,
    });

    // Keep the assistant turn in the history (including its tool requests).
    messages.push({ role: "assistant", content: response.content });

    if (response.stop_reason !== "tool_use") {
      const answer = response.content
        .filter((b): b is Anthropic.TextBlock => b.type === "text")
        .map((b) => b.text)
        .join("\n");
      console.log(`\n${answer}`);
      return;
    }

    // Run every tool the model asked for and send the results back.
    const results: Anthropic.ToolResultBlockParam[] = [];
    for (const block of response.content) {
      if (block.type !== "tool_use") continue;
      console.error(`[step ${step}] ${block.name}(${JSON.stringify(block.input)})`);
      const output = await runTool(root, block.name, block.input);
      results.push({ type: "tool_result", tool_use_id: block.id, content: output });
    }
    messages.push({ role: "user", content: results });
  }

  console.error(`Stopped after ${MAX_STEPS} steps without a final answer.`);
}

main().catch((err) => {
  console.error("Request failed:", err instanceof Error ? err.message : err);
  process.exit(1);
});
